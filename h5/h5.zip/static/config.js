const apiPrefix = '/99'
export {
  apiPrefix
}